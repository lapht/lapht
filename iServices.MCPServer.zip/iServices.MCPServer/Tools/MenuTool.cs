﻿using ModelContextProtocol.Server;
using System.ComponentModel;
using System.Text.Json;

namespace iServices.MCPServer.Tools
{
    [McpServerToolType]
    public class MenuTool
    {
        [McpServerTool, Description("Gets the weekly menu.")]
        public string GetWeeklyMenu()
        {
            return JsonSerializer.Serialize(MenuData.MenuList);
        }

        [McpServerTool, Description("Gets the daily menu.")]
        public string GetDailyMenu(
        [Description("Day of the week (0 = Sunday, 6 = Saturday)")] int day = 0)
        {
            var menu = MenuData.MenuList.Where(m => m.Day.DayOfWeek == (DayOfWeek)day);
            return JsonSerializer.Serialize(menu);
        }
    }

    public class MenuItem
    {
        public DateTime Day { get; set; }
        public string Menu { get; set; }
        public string Price { get; set; }
    }

    public static class MenuData
    {
        public static readonly List<MenuItem> MenuList = new List<MenuItem>
        {
            new MenuItem { Day = DateTime.Parse("2025-11-24"), Menu = "Minestra d'orzo", Price = "3 / 6.5CHF" },
            new MenuItem { Day = DateTime.Parse("2025-11-24"), Menu = "Pasta al pomodoro e basilico", Price = "6.5CHF" },
            new MenuItem { Day = DateTime.Parse("2025-11-24"), Menu = "Pizzoccheri Valtellinesi con o senza aglio", Price = "8CHF" },
            new MenuItem { Day = DateTime.Parse("2025-11-24"), Menu = "Bresaola", Price = "8CHF" },
            new MenuItem { Day = DateTime.Parse("2025-11-24"), Menu = "Frittata alla Spagnola", Price = "8CHF" },

            new MenuItem { Day = DateTime.Parse("2025-11-25"), Menu = "Crema di carote", Price = "3 / 6.5CHF" },
            new MenuItem { Day = DateTime.Parse("2025-11-25"), Menu = "Insalata autunnale con trevisana , melograno , mele e sfogliatine", Price = "8CHF" },
            new MenuItem { Day = DateTime.Parse("2025-11-25"), Menu = "Orecchiette al pesto di noci", Price = "6.5CHF" },
            new MenuItem { Day = DateTime.Parse("2025-11-25"), Menu = "Filetto di luccioperca FAO 05 con riso e spinaci", Price = "10CHF" },

            new MenuItem { Day = DateTime.Parse("2025-11-26"), Menu = "Minestra Thailandese", Price = "3 / 6.5CHF" },
            new MenuItem { Day = DateTime.Parse("2025-11-26"), Menu = "Casarecce zucca e castagne", Price = "6.5CHF" },
            new MenuItem { Day = DateTime.Parse("2025-11-26"), Menu = "burger vegetariano con contorni", Price = "8CHF" },
            new MenuItem { Day = DateTime.Parse("2025-11-26"), Menu = "Bistecca di manzo CH con patate e piattoni", Price = "10CHF" },

            new MenuItem { Day = DateTime.Parse("2025-11-27"), Menu = "Tacos messicano con maiale e pollo CH", Price = "10CHF" },
            new MenuItem { Day = DateTime.Parse("2025-11-27"), Menu = "Passata di verdura", Price = "3 / 6.5CHF" },
            new MenuItem { Day = DateTime.Parse("2025-11-27"), Menu = "Orecchiette ai broccoli", Price = "6.5CHF" },
            new MenuItem { Day = DateTime.Parse("2025-11-27"), Menu = "Tacos vegetariano con quorn", Price = "8CHF" },

            new MenuItem { Day = DateTime.Parse("2025-11-28"), Menu = "Crema di patate e verza", Price = "3 / 6.5CHF" },
            new MenuItem { Day = DateTime.Parse("2025-11-28"), Menu = "Maccheroni ai formaggi", Price = "6.5CHF" },
            new MenuItem { Day = DateTime.Parse("2025-11-28"), Menu = "Paella marisco", Price = "10CHF" },
            new MenuItem { Day = DateTime.Parse("2025-11-28"), Menu = "Paella vegetariana", Price = "8CHF" }
        };
    }
}
